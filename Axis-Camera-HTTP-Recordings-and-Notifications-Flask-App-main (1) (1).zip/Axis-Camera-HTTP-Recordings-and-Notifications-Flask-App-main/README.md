# Axis-Camera-HTTP-Recordings-and-Notifications-Flask-App

The Axis cmaera you must create a recipient to upload to http server

Name it and select HTTP

URL example http://IP_address_http_server:5000


Create rule 

Condtion to trigger


Action - Send Video Clip through HTTP while rule is active.

Everthing else can be left as default